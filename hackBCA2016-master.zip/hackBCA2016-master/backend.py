from flask import Flask, render_template, request, redirect
import jinja2
import os
from twilio.rest import TwilioRestClient

app = Flask(__name__)

@app.route('/')
def hello():
	return render_template("index2.html", status1="I'm ready for my first puzzle!", status2="Submit")
	
@app.route('/sms', methods=["POST"])
def sms():
	Number = "+1"+str(request.form['Number1'])
	client = TwilioRestClient("ACe79ec9f6f876dba8d755f4ef2030944e", "ea57cc52800bba1495b9f3142aa830c7")
	client.messages.create(to="+17328585355", from_="+18489995513", body="request@" + Number)
	return render_template("index2.html", status1="Success", status2="Submit")
	
@app.route('/qst', methods=["POST"])
def qst():
	Question = request.form['Question']
	Flag = request.form['Flag']
	client = TwilioRestClient("ACe79ec9f6f876dba8d755f4ef2030944e", "ea57cc52800bba1495b9f3142aa830c7")
	client.messages.create(to="+17328585355", from_="+18489995513", body="question@" + Question + "->" + Flag)
	return render_template("index2.html", status1="I'm ready for my first puzzle!", status2="Submitted")
	
@app.route('/change')
def chance():
	return redirect('/')

@app.route('/post', methods=['GET','POST'])
def post():
	if request.method == 'POST':
		return render_template('post.html')
	return render_template('get.html')

if __name__ == '__main__':
	port = int(os.environ.get('PORT', 8000))
	app.run(host='0.0.0.0', port=port,debug=True)
