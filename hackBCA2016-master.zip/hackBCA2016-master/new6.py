from twilio.rest import TwilioRestClient
import random

server_number = "+17328585355"

account_sid = "ACd6f0c8c85add0a0e31a2d7e1205aaf3e"
auth_key = "0cc58ee26f28be4873d169f0d2f196f9"

server = TwilioRestClient(account_sid, auth_key)

people = {}
questions = {"How many flags are there in the gym?":"{77}",
             "Who is the founder of Genius?":"{Tom Lehman}",
             "What is the BCA mascot?":"{The Knight}",
             "What is Kenneth's nickname?":"{Special K}"}

def getQuestion():
    return questions.keys()[random.randint(0, len(questions) - 1)]

def clear():
    for m in server.messages.list():
        if m.status.upper() != "QUEUED" and m.status.upper() != "SENT":
            server.messages.delete_instance(m.sid)

def extractNumber(request):
    return request[request.find('@') + 1:]

def extractQuestion(request):
    return request[request.find('@') + 1 : request.find('->')], request[request.find('->') + 2:]

def send(number):
    server.messages.create(to=number, from_=server_number, body=people[number])

def congratulate(number):
    server.messages.create(to=number, from_=server_number, body="congratulations!")

def scold(number):
    server.messages.create(to=number, from_=server_number, body="disappointment")

def printLs(ls):
    for i in ls:
        print(i.body)
        print("-" * 50)

clear()

while True:
    messages = server.messages.list()

    for message in messages:
        if 'request' in message.body:
            print("IN HERE")
            number = extractNumber(message.body)
            people[number] = getQuestion()
            send(number)
        elif 'question' in message.body:
            print("NOW HERE")
            question, answer = extractQuestion(message.body)
            questions[question] = answer

            for i in questions.keys():
                print(i)

            for j in questions.values():
                print(j)
            
        elif '{' in message.body and '}' in message.body:
            if questions[people[message.from_]] == message.body:
                congratulate(message.from_)
                people[message.from_] = getQuestion()
                send(message.from_)
            else:
                scold(message.from_)
    printLs(messages)
    clear()
    print("*" * 100)
    printLs(messages)
